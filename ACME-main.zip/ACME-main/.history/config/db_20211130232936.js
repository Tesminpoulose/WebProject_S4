module.exports = 
{
    "URI": "mongodb+srv://admin:L650Xs9ixkF3fwGr@cluster0.nk3nn.mongodb.net/myFirstDatabase?retryWrites=true&w=majority"
}