module.exports = 
{
    "URI": "mongodb://localhost/G5S4F21"
}