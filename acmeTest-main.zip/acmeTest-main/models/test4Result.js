let mongoose = require('mongoose');

let test4Data = mongoose.Schema
(
    {
        result:
        {
            type: Boolean,
            trim : true
        },
        item: 
        {
            type: String,
            trim : true
        }
    },
    {
        collection : 'test4'
    }
);

module.exports = mongoose.model('Test4Data', test4Data);