var express = require('express');
var router = express.Router();

let indexController = require('../controllers/indexController');



router.get('/', indexController.renderIndex);

router.get('/test1', indexController.test1test);

router.get('/test2', indexController.test2test);

router.get('/test3', indexController.test3test);

router.get('/test4', indexController.test4test);

router.get('/test5', indexController.test5test);





module.exports = router;
