'use.strict'

let express = require('express');
let router = express.Router();
let mogoose = require('mongoose');
let fs = require('fs');

let Test4Data = require('../models/test4Result');

module.exports.renderIndex = (req, res, next) => {
    res.render('index', { title: 'G5S4F21 Testing' });
}

module.exports.test1test = (req, res, next) => {
    //perform test1 here
    let file = 'public/utils/short_list.txt';
    fs.readFile(file, 'utf8', (err, data) => {
        if(err)
        {
            console.error(err);
            return;
        }
        else
        {
            let strArray = data.split('\n');
            let result;
            let marker = false;
            for(let a of strArray)
            {
                try
                {
                    result = validateField(a);
                }
                catch
                {
                    let toStore = new Test4Data({
                        result : false,
                        item : a
                    });
                    toStore.save((err, Test4Data) => {
                        if(err)
                        {
                            marker = True;
                            console.log(err);
                        }
                        else
                        {

                        }
                    });
                }
            }
            res.render('test2result', { title : 'Test 1', testNo : '1', errors : marker });
        }
    });
}

module.exports.test2test = (req, res, next) => {
    let file = 'public/utils/short_list.txt';
    fs.readFile(file, 'utf8', (err, data) => {
        if(err)
        {
            console.error(err);
            return;
        }
        else
        {
            let strArray = data.split('\n');
            let marker = false;
            for(let a of strArray)
            {
                try
                {
                    distributeLogin(a);
                }
                catch
                {
                    let toStore = new Test4Data({
                        result : false,
                        item : a
                    });
                    toStore.save((err, Test4Data) => {
                        if(err)
                        {
                            marker = True;
                            console.log(err);
                        }
                        else
                        {

                        }
                    });
                }
            }
            res.render('test2result', { title : 'Test 2', testNo : '2', errors : marker });
        }
    });
    
}

module.exports.test3test = (req, res, next) => {
   


    
    res.render('test2result');
}

module.exports.test4test = (req, res, next) => {
    
    
}

module.exports.test5test = (req, res, next) => {
    
    res.render('test2result');
}





function distributeLogin(user_account_type)
{
    if(user_account_type == 'Trainer')
    {
        //window.location.href='/trainerHome'
    }
    else if(user_account_type == 'Trainer Seeker')
    {
        //window.location.href='/seekerHome'
    }
    else if(user_account_type == 'admin')
    {
        //window.location.href='/adminHome'
    }
    else
    {
        //window.location.href='/'
    }
}

const validateField=(str)=>{
    if(str.trim()!==''){
        return true
    }
}

